<?php


namespace SleekDB\Exceptions;

class EmptyStoreNameException extends \Exception {}
