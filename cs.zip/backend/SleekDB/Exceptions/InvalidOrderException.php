<?php


namespace SleekDB\Exceptions;

class InvalidOrderException extends \Exception {}
