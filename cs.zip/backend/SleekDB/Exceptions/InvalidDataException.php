<?php


namespace SleekDB\Exceptions;

class InvalidDataException extends \Exception {}
