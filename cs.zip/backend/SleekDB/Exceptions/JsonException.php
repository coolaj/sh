<?php


namespace SleekDB\Exceptions;


if(!class_exists('JsonException')){
    class JsonException extends \Exception {}
}
